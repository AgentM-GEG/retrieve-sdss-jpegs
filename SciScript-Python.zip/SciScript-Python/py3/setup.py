from setuptools import setup, find_packages
setup(
    name = "SciServer",
    version = "2.1.0",
    packages = find_packages(),
)